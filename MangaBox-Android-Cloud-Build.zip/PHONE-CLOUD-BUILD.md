# 用手机云端编译 MangaBox APK（无需电脑）

本项目包含 GitHub Actions 工作流，可在 GitHub 云端编译 APK。你需要一个 GitHub 账号，并在手机浏览器中操作。

## 步骤

1. 在手机浏览器打开 https://github.com/new ，登录并创建一个 **Public** 仓库，仓库名可填 `MangaBox-Android`。
2. 在仓库页面选择 **Add file → Upload files**，把本项目解压后的全部文件和文件夹内容上传，确保 `.github/workflows/android.yml` 也上传。若手机网页隐藏了上传入口，可在浏览器菜单中切换“桌面版网站”。
3. 上传完成后，进入仓库的 **Actions** 页面，选择 **Build MangaBox APK** 工作流，点击 **Run workflow**（如果上传到 main 分支后自动开始构建，也可以直接等它完成）。
4. 等待工作流显示绿色成功标记。打开该次运行页面，滚动到 **Artifacts**，下载 `MangaBox-debug-apk`。
5. 解压下载的 artifact ZIP，得到 `app-debug.apk`。点击 APK 安装；若系统询问，允许浏览器或文件管理器“安装未知应用”。

## 注意

- GitHub 云端编译需要 GitHub 账号和网络连接。
- 本工作流生成的是用于个人测试的 debug APK，不是 Play 商店发布签名包。
- 不要把含有个人隐私或密钥的文件上传到 Public 仓库；本项目当前不需要密钥。
