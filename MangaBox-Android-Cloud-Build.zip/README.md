# MangaBox Android

MVP Android app for importing local ZIP/CBZ comic archives and reading images offline.

## Features
- Android Storage Access Framework archive picker
- ZIP/CBZ image extraction into app-private storage
- Natural filename sorting (1, 2, 10 rather than 1, 10, 2)
- White library UI with cover thumbnails
- Horizontal paging and vertical continuous reading
- Reading progress persistence
- Rename and delete comics

## Build
1. Install Android Studio (Ladybug or newer) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync and install the required SDK/build tools.
4. Select the `app` run configuration and run on an Android device, or use Build > Build Bundle(s) / APK(s) > Build APK(s).

The generated APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- This is a source project, not a prebuilt APK.
- The first version supports ZIP/CBZ archives containing JPG/JPEG/PNG/WEBP/GIF/BMP images.
- Archives are extracted into app-private storage. Uninstalling the app removes its imported library.
- For very large archives, allow the import operation to finish before leaving the app.
