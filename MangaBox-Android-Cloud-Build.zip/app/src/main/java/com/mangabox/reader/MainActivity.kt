package com.mangabox.reader

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.zip.ZipInputStream

private data class Comic(
    val id: String,
    val name: String,
    val folder: String,
    val pages: List<String>,
    val progress: Int = 0
)

private enum class ReadingMode { HORIZONTAL, VERTICAL }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MangaBoxApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MangaBoxApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var comics by remember { mutableStateOf(loadLibrary(context)) }
    var selected by remember { mutableStateOf<Comic?>(null) }
    var mode by remember { mutableStateOf(ReadingMode.HORIZONTAL) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var renameTarget by remember { mutableStateOf<Comic?>(null) }
    var renameText by remember { mutableStateOf("") }
    var menuTarget by remember { mutableStateOf<String?>(null) }

    fun updateComic(updated: Comic) {
        comics = comics.map { if (it.id == updated.id) updated else it }
        saveLibrary(context, comics)
        if (selected?.id == updated.id) selected = updated
    }

    val importer = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                busy = true
                message = null
                try {
                    val comic = withContext(Dispatchers.IO) { importArchive(context, uri) }
                    comics = comics + comic
                    saveLibrary(context, comics)
                    message = "导入完成：${comic.name}（${comic.pages.size} 张图片）"
                } catch (e: Exception) {
                    message = "导入失败：${e.message ?: "压缩包无法读取"}"
                } finally {
                    busy = false
                }
            }
        }
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF222222),
            onPrimary = androidx.compose.ui.graphics.Color.White,
            background = androidx.compose.ui.graphics.Color(0xFFFAFAFA),
            surface = androidx.compose.ui.graphics.Color.White
        )
    ) {
        if (selected != null) {
            ReaderScreen(
                comic = selected!!,
                mode = mode,
                onModeChange = { mode = it },
                onBack = { selected = null },
                onProgress = { page ->
                    val current = comics.firstOrNull { it.id == selected?.id }
                    if (current != null && current.progress != page) {
                        updateComic(current.copy(progress = page))
                    }
                }
            )
        } else {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text("MangaBox", fontWeight = FontWeight.Bold)
                                Text("我的漫画书架", style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        },
                        actions = {
                            IconButton(onClick = { importer.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }) {
                                Icon(Icons.Default.Add, contentDescription = "导入漫画")
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                    )
                },
                floatingActionButton = {
                    ExtendedFloatingActionButton(
                        onClick = { importer.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                        icon = { Icon(Icons.Default.Add, contentDescription = null) },
                        text = { Text("导入漫画") }
                    )
                },
                containerColor = MaterialTheme.colorScheme.background
            ) { padding ->
                Column(Modifier.fillMaxSize().padding(padding)) {
                    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                    message?.let {
                        Text(it, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                            color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                    }
                    if (comics.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Icon(Icons.Default.MenuBook, contentDescription = null, modifier = Modifier.size(64.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("书架还是空的", style = MaterialTheme.typography.titleLarge)
                                Text("导入 ZIP 或 CBZ 漫画压缩包即可开始阅读",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Button(onClick = { importer.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }) {
                                    Text("选择压缩包")
                                }
                            }
                        }
                    } else {
                        LazyVerticalGrid(
                            columns = GridCells.Adaptive(minSize = 142.dp),
                            contentPadding = PaddingValues(14.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            items(comics, key = { it.id }) { comic ->
                                Column {
                                    Box {
                                        AsyncImage(
                                            model = File(context.filesDir, "${comic.folder}/${comic.pages.firstOrNull().orEmpty()}"),
                                            contentDescription = comic.name,
                                            modifier = Modifier.fillMaxWidth().height(205.dp)
                                                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
                                                .clickable { selected = comic },
                                            contentScale = ContentScale.Crop
                                        )
                                        Box(Modifier.align(Alignment.TopEnd)) {
                                            IconButton(onClick = { menuTarget = comic.id }) {
                                                Icon(Icons.Default.MoreVert, contentDescription = "更多操作",
                                                    tint = MaterialTheme.colorScheme.onSurface)
                                            }
                                            DropdownMenu(expanded = menuTarget == comic.id, onDismissRequest = { menuTarget = null }) {
                                                DropdownMenuItem(text = { Text("重命名") }, onClick = {
                                                    renameTarget = comic
                                                    renameText = comic.name
                                                    menuTarget = null
                                                })
                                                DropdownMenuItem(
                                                    text = { Text("删除") },
                                                    leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null) },
                                                    onClick = {
                                                        File(context.filesDir, comic.folder).deleteRecursively()
                                                        comics = comics.filterNot { it.id == comic.id }
                                                        saveLibrary(context, comics)
                                                        menuTarget = null
                                                    }
                                                )
                                            }
                                        }
                                    }
                                    Spacer(Modifier.height(7.dp))
                                    Text(comic.name, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                        fontWeight = FontWeight.SemiBold)
                                    Text("${comic.pages.size} 页 · 已读到 ${comic.progress + 1} 页",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
            if (renameTarget != null) {
                AlertDialog(
                    onDismissRequest = { renameTarget = null },
                    title = { Text("重命名漫画") },
                    text = {
                        OutlinedTextField(value = renameText, onValueChange = { renameText = it },
                            singleLine = true, label = { Text("漫画名称") })
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            renameTarget?.let { updateComic(it.copy(name = renameText.trim().ifBlank { it.name })) }
                            renameTarget = null
                        }) { Text("保存") }
                    },
                    dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("取消") } }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun ReaderScreen(
    comic: Comic,
    mode: ReadingMode,
    onModeChange: (ReadingMode) -> Unit,
    onBack: () -> Unit,
    onProgress: (Int) -> Unit
) {
    val context = LocalContext.current
    val pagerState = rememberPagerState(initialPage = comic.progress.coerceIn(0, comic.pages.lastIndex)) {
        comic.pages.size
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(comic.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${comic.progress + 1} / ${comic.pages.size}",
                            style = MaterialTheme.typography.labelSmall)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "返回书架") }
                },
                actions = {
                    TextButton(onClick = {
                        onModeChange(if (mode == ReadingMode.HORIZONTAL) ReadingMode.VERTICAL else ReadingMode.HORIZONTAL)
                    }) {
                        Text(if (mode == ReadingMode.HORIZONTAL) "上下滚动" else "左右翻页")
                    }
                }
            )
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding).background(androidx.compose.ui.graphics.Color(0xFFF1F1F1))) {
            if (mode == ReadingMode.HORIZONTAL) {
                LaunchedEffect(pagerState.currentPage) { onProgress(pagerState.currentPage) }
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxSize()
                ) { page ->
                    AsyncImage(
                        model = File(context.filesDir, "${comic.folder}/${comic.pages[page]}"),
                        contentDescription = "第 ${page + 1} 页",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                }
            } else {
                val listState = androidx.compose.foundation.lazy.rememberLazyListState(
                    initialFirstVisibleItemIndex = comic.progress.coerceIn(0, comic.pages.lastIndex)
                )
                LaunchedEffect(listState.firstVisibleItemIndex) {
                    onProgress(listState.firstVisibleItemIndex)
                }
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    itemsIndexed(comic.pages) { index, page ->
                        AsyncImage(
                            model = File(context.filesDir, "${comic.folder}/$page"),
                            contentDescription = "第 ${index + 1} 页",
                            modifier = Modifier.fillMaxWidth(),
                            contentScale = ContentScale.FillWidth
                        )
                    }
                }
            }
        }
    }
}

private fun importArchive(context: Context, uri: Uri): Comic {
    val id = UUID.randomUUID().toString()
    val folder = "comic_$id"
    val targetDir = File(context.filesDir, folder)
    if (!targetDir.mkdirs()) error("无法创建漫画目录")

    val rawNames = mutableListOf<Pair<String, File>>()
    var count = 0
    try {
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "无法打开所选文件" }
            ZipInputStream(input.buffered()).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory) {
                        val originalName = entry.name.substringAfterLast('/').substringAfterLast('\\')
                        val ext = originalName.substringAfterLast('.', "").lowercase()
                        if (ext in setOf("jpg", "jpeg", "png", "webp", "gif", "bmp")) {
                            count++
                            val safeName = originalName.replace(Regex("[^A-Za-z0-9._-]"), "_").take(100).ifBlank { "page.$ext" }
                            val temp = File(targetDir, "raw_${count}_$safeName")
                            temp.outputStream().buffered().use { out -> zip.copyTo(out) }
                            rawNames += originalName to temp
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        }
        if (rawNames.isEmpty()) error("压缩包内没有找到 JPG、PNG、WEBP 等图片")
        val sorted = rawNames.sortedWith { a, b -> naturalCompare(a.first, b.first) }
        val finalPages = sorted.mapIndexed { index, pair ->
            val ext = pair.second.extension.ifBlank { "jpg" }
            val finalName = "%05d.%s".format(index + 1, ext)
            val dest = File(targetDir, finalName)
            if (!pair.second.renameTo(dest)) pair.second.copyTo(dest, overwrite = true)
            pair.second.delete()
            finalName
        }
        val archiveName = queryDisplayName(context, uri).substringBeforeLast('.').ifBlank { "未命名漫画" }
        return Comic(id, archiveName, folder, finalPages, 0)
    } catch (e: Exception) {
        targetDir.deleteRecursively()
        throw e
    }
}

private fun naturalCompare(left: String, right: String): Int {
    var i = 0
    var j = 0
    while (i < left.length && j < right.length) {
        val c1 = left[i]
        val c2 = right[j]
        if (c1.isDigit() && c2.isDigit()) {
            val startI = i
            val startJ = j
            while (i < left.length && left[i].isDigit()) i++
            while (j < right.length && right[j].isDigit()) j++
            val n1 = left.substring(startI, i).trimStart('0').ifEmpty { "0" }
            val n2 = right.substring(startJ, j).trimStart('0').ifEmpty { "0" }
            if (n1.length != n2.length) return n1.length.compareTo(n2.length)
            val numberCompare = n1.compareTo(n2)
            if (numberCompare != 0) return numberCompare
        } else {
            val compare = c1.lowercaseChar().compareTo(c2.lowercaseChar())
            if (compare != 0) return compare
            i++
            j++
        }
    }
    return (left.length - i).compareTo(right.length - j)
}

private fun queryDisplayName(context: Context, uri: Uri): String {
    return try {
        context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else "未命名漫画.zip"
            } ?: "未命名漫画.zip"
    } catch (_: Exception) { "未命名漫画.zip" }
}

private fun saveLibrary(context: Context, comics: List<Comic>) {
    val array = JSONArray()
    comics.forEach { comic ->
        array.put(JSONObject().apply {
            put("id", comic.id)
            put("name", comic.name)
            put("folder", comic.folder)
            put("progress", comic.progress)
            put("pages", JSONArray(comic.pages))
        })
    }
    context.getSharedPreferences("mangabox", Context.MODE_PRIVATE)
        .edit().putString("library", array.toString()).apply()
}

private fun loadLibrary(context: Context): List<Comic> {
    return try {
        val raw = context.getSharedPreferences("mangabox", Context.MODE_PRIVATE)
            .getString("library", "[]") ?: "[]"
        val array = JSONArray(raw)
        (0 until array.length()).mapNotNull { index ->
            val obj = array.getJSONObject(index)
            val pagesJson = obj.getJSONArray("pages")
            val pages = (0 until pagesJson.length()).map { pagesJson.getString(it) }
            Comic(obj.getString("id"), obj.getString("name"), obj.getString("folder"),
                pages, obj.optInt("progress", 0).coerceIn(0, (pages.size - 1).coerceAtLeast(0)))
        }.filter { File(context.filesDir, it.folder).exists() && it.pages.isNotEmpty() }
    } catch (_: Exception) { emptyList() }
}
